from flask import Flask, render_template, request
import pandas as pd
import numpy as np

app = Flask(__name__)

data = {
    'pages': [
        {'route': '/', 'name': 'Market Overview'},
        {'route': '/indicators', 'name': 'Economic Indicators'},
        {'route': '/fair-value', 'name': 'Fair Value Analysis'},
        {'route': '/calendar', 'name': 'Economic Calendar'},
        {'route': '/valuation', 'name': 'Company Valuation'},
    ]
}

def fetch_sp500():
    current = 5200
    pe = 25.0
    eps = current / pe
    hist = np.cumsum(np.random.randn(365)) + current
    dates = pd.date_range(end=pd.Timestamp.today(), periods=365)
    history = list(zip(dates.strftime('%Y-%m-%d'), hist))
    return {'current': current, 'pe': pe, 'eps': eps, 'history': history}

def fetch_indicators():
    return {
        'Unemployment Rate': {'val': 4.1, 'chg': 0.1, 'status': 'caution', 'hist': np.random.uniform(3.5,4.5,12).tolist()},
        'BBB Spread': {'val': 1.2, 'chg': 0.05, 'status': 'good', 'hist': np.random.uniform(0.5,2.0,120).tolist()},
    }

@app.route('/')
def home():
    sp = fetch_sp500()
    score = 50
    return render_template('index.html', pages=data['pages'], sp=sp, score=score)

@app.route('/indicators')
def indicators():
    inds = fetch_indicators()
    return render_template('indicators.html', pages=data['pages'], indicators=inds)

@app.route('/fair-value')
def fair_value():
    sp = fetch_sp500()
    g = 0.06; r = 0.08
    fv = sp['eps'] * (1+g) / (r-g)
    return render_template('fair_value.html', pages=data['pages'], fv=fv)

@app.route('/calendar')
def calendar():
    events = [
        {'date': '2025-06-10', 'event': 'FOMC Meeting', 'time': '14:00 CET'},
        {'date': '2025-06-15', 'event': 'US CPI Release', 'time': '13:30 CET'},
    ]
    return render_template('calendar.html', pages=data['pages'], events=events)

@app.route('/valuation', methods=['GET', 'POST'])
def valuation():
    result = None
    if request.method == 'POST':
        D = float(request.form['D'])
        E = float(request.form['E'])
        FCF = float(request.form['FCF'])
        shares = float(request.form['shares'])
        G = float(request.form['G'])
        Gs = float(request.form['Gs'])
        r = float(request.form['r'])
        FCF_ps = FCF / shares
        scenarios = {'No Growth': 0.0, 'Growth': G, 'Surge Growth': Gs}
        metrics = {'Dividend': D, 'Earnings': E, 'FCF per share': FCF_ps}
        result = {
            scen: {
                m: ((metrics[m] * (1+scenarios[scen])) / (r-scenarios[scen])) if r>scenarios[scen] else None
                for m in metrics
            }
            for scen in scenarios
        }
    return render_template('valuation.html', pages=data['pages'], result=result)

if __name__ == '__main__':
    app.run(debug=True)
